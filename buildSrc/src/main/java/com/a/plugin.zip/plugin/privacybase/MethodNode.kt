package com.a.plugin.privacybase

data class MethodNode(var owner: String?, var name: String?, var descriptor: String?)